function xq = qIdeal(x)

xq = x;

end