function xq = qUniform(x,q)

xq = round(x/q)*q;

end