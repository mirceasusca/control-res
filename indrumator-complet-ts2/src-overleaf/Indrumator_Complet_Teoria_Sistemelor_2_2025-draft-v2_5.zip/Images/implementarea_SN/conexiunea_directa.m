% perioada de esantionare
Te=0.2;
% functia de transfer cu zoh
Hd=c2d(tf(1,[1 3 2]),Te,'zoh');
% extragerea numaratorului si numitorului
[num,den]=tfdata(Hd,'v');
% extragerea parametrilor pentru implementare
a2=den(3); a1=den(2);
b2=num(3); b1=num(2);
% conditiile initiale
y(1)=0;
y(2)=b1;
% numarul de esantioane
n=30;
% semnalul de intrare
u=ones(1,n);
% implementarea sistemului numeric
for k=3:n
    y(k)=b2*u(k-2)+b1*u(k-1)-a2*y(k-2)-a1*y(k-1);
end
% timpul de simulare
te=0:Te:(n-1)*Te;
% comparatia intre ce s-a calculat si ce returneaza MATLAB
stairs(te,y,'r*');hold;step(Hd)