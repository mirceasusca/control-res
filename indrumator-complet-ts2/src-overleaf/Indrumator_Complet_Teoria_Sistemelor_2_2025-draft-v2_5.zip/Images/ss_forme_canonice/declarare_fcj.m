num=[6, 21, 23, 20]; den=[2, 7, 7, 2];
% obtinerea reziduurilor si a polilor
[R,P,Rinf] = residue(num,den);
% determinarea matricelor corespunzatoare FCJ
A_FCJ = diag(P);
B_FCJ = ones(length(P),1);
C_FCJ = R'; 
D = Rinf; % daca Rinf este vector gol, se pune 0
% crearea obiectului de tip spatiul starilor
sys=ss(A_FCJ,B_FCJ,C_FCJ,D); 