num=[6, 21, 23, 20]; den=[2, 7, 7, 2];
% extinderea numaratorului 
N = 3; num_ext=[num, zeros(1,N)];
% forteaza minim primii N parametri Markov
gamma=deconv(num_ext,den); 

