num=[6, 21, 23, 20]; den=[2, 7, 7, 2];
% determinarea matricelor corespunzatoare FCC
[A_FCC,B_FCC,C_FCC,D]=tf2ss(num,den); 
% crearea obiectului de tip spatiul starilor
sys=ss(A_FCC,B_FCC,C_FCC,D); 
