fe = 2000;          % frecventa de esantionare [Hz]
fN = fe/2;          % frecventa Nyquist
N = 8;  % N = ordinul filtrului / 2 (in cazurile FTB si FOB)
Wp = [300 700]/fN;  % banda de trecere (bandpass)
Ws = [250 750]/fN;  % banda de oprire (bandstop)
rp = 1;    % ondulatia maxima in banda de trecere [dB]
rs = 60;   % atenuarea minima [dB] in banda de oprire
[B, A] = ellip(N, rp, rs, Ws, 'stop');
freqz(B, A, 1024, fe);
title('Diagrama Bode, FOB eliptic');
