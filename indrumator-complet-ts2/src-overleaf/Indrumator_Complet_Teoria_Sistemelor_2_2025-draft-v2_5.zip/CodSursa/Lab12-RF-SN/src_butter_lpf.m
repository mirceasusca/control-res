fe = 1000;   % frecventa de esantionare [Hz]
fN = fe/2;   % frecventa Nyquist
N = 4;       % N = ordinul filtrului (in cazurile FTJ si FTS)
Fc = 150/fN; % frecventa de taiere normalizata (150 Hz)
[B, A] = butter(N, Fc, 'low');
% vizualizarea raspunsului
freqz(B, A, 1024, fe);
title('Diagrama Bode, FTJ Butterworth');